var blonweThemeModule = {};
/* global blonwe_settings */

(function($) {

	blonweThemeModule.$window = $(window);

	blonweThemeModule.$document = $(document);

	blonweThemeModule.$body = $('body');


	
})(jQuery);